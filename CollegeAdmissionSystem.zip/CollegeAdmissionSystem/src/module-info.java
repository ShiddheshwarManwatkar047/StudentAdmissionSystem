/**
 * 
 */
/**
 * 
 */
module CollegeAdmissionSystem {
	requires java.sql;
}