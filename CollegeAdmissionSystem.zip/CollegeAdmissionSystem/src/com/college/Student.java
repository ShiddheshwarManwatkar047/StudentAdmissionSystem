package com.college;

public class Student {
    private int id;
    private String fullName;
    private String email;
    private double score;

    public Student(int id, String fullName, String email, double score) {
        this.id = id; this.fullName = fullName; this.email = email; this.score = score;
    }
    public Student(String fullName, String email, double score) {
        this(0, fullName, email, score);
    }
    public int getId() { return id; }
    public String getFullName() { return fullName; }
    public String getEmail() { return email; }
    public double getScore() { return score; }
}