package com.college;

import java.util.*;

public class AdminConsole {
    private static AdmissionDAO dao = new AdmissionDAO();
    private static MeritCalculator mc = new MeritCalculator();
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        while (true) {
            System.out.println("--- Admin Panel ---");
            System.out.println("1. Create course\n2. Register student\n3. Apply student to course\n4. Run seat allocation\n5. Export admitted CSV\n6. Exit");
            System.out.print("Choice: ");
            int ch = Integer.parseInt(sc.nextLine());
            switch(ch) {
                case 1: createCourse(); break;
                case 2: registerStudent(); break;
                case 3: applyStudent(); break;
                case 4: runAllocation(); break;
                case 5: exportCSV(); break;
                case 6: System.exit(0);
                default: System.out.println("Invalid");
            }
        }
    }

    static void createCourse() throws Exception {
        System.out.print("Course code: "); String code = sc.nextLine();
        System.out.print("Course name: "); String name = sc.nextLine();
        System.out.print("Seats: "); int seats = Integer.parseInt(sc.nextLine());
        Course c = new Course(code, name, seats);
        int id = dao.insertCourse(c);
        System.out.println("Created course id: " + id);
    }

    static void registerStudent() throws Exception {
        System.out.print("Full name: "); String name = sc.nextLine();
        System.out.print("Email: "); String email = sc.nextLine();
        System.out.print("Score (0-100): "); double score = Double.parseDouble(sc.nextLine());
        Student s = new Student(name, email, score);
        int id = dao.insertStudent(s);
        System.out.println("Student id: " + id);
    }

    static void applyStudent() throws Exception {
        System.out.print("Student id: "); int sid = Integer.parseInt(sc.nextLine());
        System.out.print("Course id: "); int cid = Integer.parseInt(sc.nextLine());
        dao.applyToCourse(sid, cid);
        System.out.println("Applied successfully");
    }

    static void runAllocation() throws Exception {
        System.out.print("Course id to allocate: "); int cid = Integer.parseInt(sc.nextLine());
        mc.allocateSeats(cid);
        System.out.println("Allocation complete.");
    }

    static void exportCSV() throws Exception {
        System.out.print("Course id: "); int cid = Integer.parseInt(sc.nextLine());
        System.out.print("Output file path (e.g. admitted_course1.csv): "); String fp = sc.nextLine();
        dao.exportAdmittedCSV(cid, fp);
        System.out.println("CSV exported to: " + fp);
    }
}