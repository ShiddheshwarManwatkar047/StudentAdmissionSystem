package com.college;

public class Course {
    private int id; private String code; private String name; private int seats;
    public Course(int id, String code, String name, int seats) { this.id = id; this.code = code; this.name = name; this.seats = seats; }
    public Course(String code, String name, int seats) { this(0, code, name, seats); }
    public int getId() { return id; }
    public String getCode() { return code; }
    public String getName() { return name; }
    public int getSeats() { return seats; }
}