package com.college;

public class Application {
    private int id; private int studentId; private int courseId; private String status; private Integer rank;
    public Application(int id, int studentId, int courseId, String status, Integer rank) {
        this.id = id; this.studentId = studentId; this.courseId = courseId; this.status = status; this.rank = rank;
    }
    public int getId() { return id; }
    public int getStudentId() { return studentId; }
    public int getCourseId() { return courseId; }
    public String getStatus() { return status; }
    public Integer getRank() { return rank; }
}