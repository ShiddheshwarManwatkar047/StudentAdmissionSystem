package com.college;

import java.sql.*;
import java.util.*;

public class AdmissionDAO {
    public int insertStudent(Student s) throws SQLException {
        String sql = "INSERT INTO students(full_name,email,score) VALUES(?,?,?)";
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, s.getFullName()); ps.setString(2, s.getEmail()); ps.setDouble(3, s.getScore());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        return -1;
    }

    public int insertCourse(Course course) throws SQLException {
        String sql = "INSERT INTO courses(course_code,course_name,seats) VALUES(?,?,?)";
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, course.getCode()); ps.setString(2, course.getName()); ps.setInt(3, course.getSeats());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) { if (rs.next()) return rs.getInt(1); }
        }
        return -1;
    }

    public void applyToCourse(int studentId, int courseId) throws SQLException {
        String sql = "INSERT INTO applications(student_id, course_id) VALUES(?,?)";
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, studentId); ps.setInt(2, courseId); ps.executeUpdate();
        }
    }

    public List<Map<String,Object>> getApplicantsForCourse(int courseId) throws SQLException {
        String sql = "SELECT a.application_id, s.student_id, s.full_name, s.email, s.score FROM applications a JOIN students s ON a.student_id=s.student_id WHERE a.course_id=? AND a.status='PENDING' ORDER BY s.score DESC";
        List<Map<String,Object>> list = new ArrayList<>();
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Map<String,Object> m = new HashMap<>();
                    m.put("application_id", rs.getInt(1));
                    m.put("student_id", rs.getInt(2));
                    m.put("full_name", rs.getString(3));
                    m.put("email", rs.getString(4));
                    m.put("score", rs.getDouble(5));
                    list.add(m);
                }
            }
        }
        return list;
    }

    public void updateApplicationStatus(int applicationId, String status, Integer rank) throws SQLException {
        String sql = "UPDATE applications SET status=?, rank=? WHERE application_id=?";
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, status); if (rank==null) ps.setNull(2, Types.INTEGER); else ps.setInt(2, rank);
            ps.setInt(3, applicationId); ps.executeUpdate();
        }
    }

    public Course getCourseById(int courseId) throws SQLException {
        String sql = "SELECT course_id,course_code,course_name,seats FROM courses WHERE course_id=?";
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return new Course(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4));
            }
        }
        return null;
    }

    public void exportAdmittedCSV(int courseId, String filepath) throws SQLException {
        String sql = "SELECT s.full_name, s.email, s.score, a.rank FROM applications a JOIN students s ON a.student_id=s.student_id WHERE a.course_id=? AND a.status='ACCEPTED' ORDER BY a.rank";
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            try (ResultSet rs = ps.executeQuery(); java.io.PrintWriter pw = new java.io.PrintWriter(filepath)) {
                pw.println("Rank,Full Name,Email,Score");
                while (rs.next()) {
                    pw.printf("%d,%s,%s,%.2f\n", rs.getInt(4), rs.getString(1), rs.getString(2), rs.getDouble(3));
                }
            } catch (java.io.FileNotFoundException e) { e.printStackTrace(); }
        }
    }
}