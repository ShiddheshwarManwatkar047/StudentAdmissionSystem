package com.college;

import java.sql.SQLException;
import java.util.List;

public class MeritCalculator {
    private AdmissionDAO dao = new AdmissionDAO();

    public void allocateSeats(int courseId) throws SQLException {
        Course course = dao.getCourseById(courseId);
        if (course == null) throw new IllegalArgumentException("Course not found");
        int seats = course.getSeats();
        List<java.util.Map<String,Object>> applicants = dao.getApplicantsForCourse(courseId);
        int rank = 1; int admitted = 0;
        for (java.util.Map<String,Object> app : applicants) {
            int applicationId = (Integer) app.get("application_id");
            if (admitted < seats) {
                dao.updateApplicationStatus(applicationId, "ACCEPTED", rank);
                admitted++; rank++;
            } else {
                dao.updateApplicationStatus(applicationId, "REJECTED", null);
            }
        }
    }
}